package com.yingql.android.games.supermario;

import org.loon.framework.android.game.core.LSystem;
import org.loon.framework.android.game.core.graphics.LColor;
import org.loon.framework.android.game.core.graphics.Screen;
import org.loon.framework.android.game.core.graphics.Touch;
import org.loon.framework.android.game.core.graphics.device.LGraphics;
import org.loon.framework.android.game.core.timer.LTimer;
import org.loon.framework.android.game.core.timer.LTimerContext;

import android.view.KeyEvent;

import com.yingql.android.games.supermario.sprite.NavigationKey;
import com.yingql.android.games.supermario.tmx.ScalableMode;

/**
 * ����Ļ
 * 
 * @author yingql
 * 
 */
public class MainScreen extends Screen
{
	/**
	 * ��Ϸ��ͼ
	 */
	private Map map;

	/**
	 * ��Ϸ�ķ����
	 */
	private NavigationKey navigationKey;

	/**
	 * ��Ϸ����ɫ
	 */
	private LColor background = new LColor(84, 112, 255);

	private LTimer timer = new LTimer(LSystem.SECOND);

	/*
	 * ִ������Ķ�ʱ����
	 */
	@Override
	public void alter(LTimerContext context)
	{
		if (timer.action(context.getTimeSinceLastUpdate()))
		{
		}
	}

	/**
	 * @return ������Ϸ��ͼ
	 */
	public Map getMap()
	{
		return map;
	}

	@Override
	public void onLoad()
	{
		// ����������תΪ���̷���
		setGravityToKey(false);
		setFPS(100);
		// ����TMX��ͼ��XML��ͼƬ����·����assets�ļ�����
		map = new Map(this, "assets/map/level 1-1.tmx", "assets", ScalableMode.Height, 0, 16);
		navigationKey = new NavigationKey(this, map.getMario());
		// ������ʾ
		centerOn(map.getLayer());
		// ���ӵ�Screen
		add(map.getLayer());
		this.add(navigationKey);
	}

	@Override
	public void draw(LGraphics g)
	{
		// ��onLoad����Դȫ���������ʱ
		if (isOnLoadComplete())
		{
			// ���Ʊ���
			g.rectFill(0, 0, this.getWidth(), this.getHeight(), background);
			// ����TMX��ͼ����Ļ
			map.draw(g);
		}
	}

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent e)
	{
		int key = e.getKeyCode();
		if (key == KeyEvent.KEYCODE_DPAD_LEFT)
		{
			this.map.getMario().stop();
		}
		if (key == KeyEvent.KEYCODE_DPAD_RIGHT)
		{
			this.map.getMario().stop();
		}
		return true;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent e)
	{
		int key = e.getKeyCode();
		if (key == KeyEvent.KEYCODE_DPAD_LEFT)
		{
			this.map.getMario().left();
		}
		if (key == KeyEvent.KEYCODE_DPAD_RIGHT)
		{
			this.map.getMario().right();
		}
		if (key == KeyEvent.KEYCODE_DPAD_UP)
		{
			this.map.getMario().jump();
		}
		if (key == KeyEvent.KEYCODE_DPAD_DOWN)
		{
			this.map.getMario().down();
		}
		return true;
	}

	@Override
	public void onTouchDown(Touch touch)
	{
		navigationKey.onTouchDown(touch);
	}

	@Override
	public void onTouchMove(Touch touch)
	{
		navigationKey.onTouchMove(touch);
	}

	@Override
	public void onTouchUp(Touch touch)
	{
		navigationKey.onTouchUp(touch);
	}
}
