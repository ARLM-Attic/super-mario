package com.yingql.android.games.supermario.sprite;

import org.loon.framework.android.game.core.graphics.LImage;

import com.yingql.android.games.supermario.Map;

/**
 * ������
 * 
 * @author yingql
 * 
 */
public class Goomba extends MoveableSpriteBase
{
	private static LImage image = null;	

	public Goomba(Map map)
	{
		super(map);		
		if (Goomba.image == null)
		{
			Goomba.image = new LImage("assets/characters/goomba1.png");
			Goomba.image = map.scaleImage(Goomba.image);
		}
		this.setImage(Goomba.image);
	}
}
