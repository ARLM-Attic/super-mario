package com.yingql.android.games.supermario.tmx;

/**
 * ����ģʽ
 * 
 * @author yingql
 * 
 */
public enum ScalableMode
{
	None, Width, Height, WidthAndHeight
}
