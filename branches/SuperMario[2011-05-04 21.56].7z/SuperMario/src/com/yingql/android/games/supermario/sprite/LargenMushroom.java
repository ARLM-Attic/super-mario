package com.yingql.android.games.supermario.sprite;

import org.loon.framework.android.game.core.graphics.LImage;

import com.yingql.android.games.supermario.Map;

/**
 * ���Ģ������
 * 
 * @author yingql
 * 
 */
public class LargenMushroom extends MoveableSpriteBase
{
	private static LImage image = null;
	
	public LargenMushroom(Map map)
	{
		super(map);
		if (LargenMushroom.image == null)
		{
			LargenMushroom.image = new LImage("assets/bonus/pilz.png");
			LargenMushroom.image = map.scaleImage(LargenMushroom.image);
		}
		this.isAdded = true;
		this.setImage(LargenMushroom.image);
		// �����ʼ�ٶ�
		this.unitSpeed = this.map.getTileWidth() / 6;				
		this.getSpeed().set(0, unitSpeed);
	}
}
