package com.yingql.android.games.supermario.tmx;

import org.loon.framework.android.game.action.map.tmx.TMXProperty;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class TMXTile
{
	public int index;

	public String name;

	public String type;

	public int x;

	public int y;

	public int width;

	public int height;

	public int gid;
	
	String image;

	public TMXProperty props;

	public TMXTile(Element element) throws RuntimeException {
		name = element.getAttribute("name");
		type = element.getAttribute("type");		
		x = Integer.parseInt(element.getAttribute("x"));
		y = Integer.parseInt(element.getAttribute("y"));
		String w = element.getAttribute("width");
		String h = element.getAttribute("height");
		String g = element.getAttribute("gid");
		gid = Integer.parseInt(g == null || "".equals(g) ? "0" : g);
		width = Integer.parseInt(w == null || "".equals(w) ? "0" : w);
		height = Integer.parseInt(h == null || "".equals(h) ? "0" : h);
		Element imageElement = (Element) element.getElementsByTagName("image")
				.item(0);
		if (imageElement != null) {
			image = imageElement.getAttribute("source");
		}

		Element propsElement = (Element) element.getElementsByTagName(
				"properties").item(0);
		if (propsElement != null) {
			NodeList properties = propsElement.getElementsByTagName("property");
			if (properties != null) {
				props = new TMXProperty();
				for (int p = 0; p < properties.getLength(); p++) {
					Element propElement = (Element) properties.item(p);

					String name = propElement.getAttribute("name");
					String value = propElement.getAttribute("value");
					props.setProperty(name, value);
				}
			}
		}
	}
}
