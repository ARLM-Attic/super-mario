package com.yingql.android.games.supermario.sprite;

import org.loon.framework.android.game.core.graphics.LComponent;
import org.loon.framework.android.game.core.graphics.Touch;
import org.loon.framework.android.game.core.graphics.device.LGraphics;
import org.loon.framework.android.game.core.timer.LTimer;

import android.graphics.Point;

import com.yingql.android.games.supermario.MainScreen;

/**
 * ģ��ķ����
 * 
 * @author yingql
 * 
 */
public class NavigationKey extends LComponent
{
	private Mario mario;

	private MainScreen screen;

	private LTimer timer = new LTimer(0);

	// private LColor controlPointColor = new LColor(0, 0, 255, 122);

	/**
	 * �Ƿ��£����������Ҫ���ƿ���ť
	 */
	private boolean isTouchDown = false;

	/**
	 * ���ص�λ��
	 */
	private Point touchPoint = new Point();

	/**
	 * ���ĵ�
	 */
	private Point centerPoint;

	/**
	 * ��С�Ŀ��ư�ť�뾶
	 */
	private static final int MinRadius = 30;

	/**
	 * ����Ļ��Ե����С����
	 */
	private static final int MinOffset = 20;

	private int radius, diameter, offset;

	public Point getCenterPoint()
	{
		return centerPoint;
	}

	public int getRadius()
	{
		return radius;
	}

	public int getDiameter()
	{
		return diameter;
	}

	public int getOffset()
	{
		return offset;
	}

	public NavigationKey(MainScreen screen, Mario mario)
	{
		super(0, 0, 0, 0);
		this.mario = mario;
		this.screen = screen;
		this.customRendering = true;
		timer.setDelay(500);
		initLocation();
	}

	@Override
	public String getUIName()
	{
		return "NavigationKey";
	}

	@Override
	protected void createCustomUI(LGraphics g, int x, int y, int w, int h)
	{
		g.setColor(0, 0, 255, 122);
		// ���ݴ��ص�λ�û��ƿ���ť
		if (isTouchDown)
		{
			g.fillOval(touchPoint.x - this.radius, touchPoint.y - this.radius, this.diameter, this.diameter);
		}
		else
		{
			g.fillOval(centerPoint.x - this.radius, centerPoint.y - this.radius, this.diameter, this.diameter);
		}
	}

	@Override
	public void update(long elapsedTime)
	{
		if (timer.action(elapsedTime))
		{
			setDirection();
		}
	}

	public void onTouchDown(Touch touch)
	{
		// �ڷ�����ڰ���
		if (isIn((int) touch.getX(), (int) touch.getY()))
		{
			isTouchDown = true;
			touchPoint.set((int) touch.getX(), (int) touch.getY());
		}
	}

	public void onTouchMove(Touch touch)
	{
		if (isTouchDown)
		{
			touchPoint.set((int) touch.getX(), (int) touch.getY());
		}
	}

	public void onTouchUp(Touch touch)
	{
		isTouchDown = false;
	}

	/**
	 * ��ʼ���������λ��
	 */
	private void initLocation()
	{
		// �뾶������Ļ��Ե�ľ���ֱ�Ϊ��Ƭ��С��2����1��
		this.radius = Math.max(this.screen.getMap().getTileWidth() * 2, MinRadius);
		this.diameter = this.radius * 2;
		this.offset = Math.max(this.screen.getMap().getTileWidth(), MinOffset);
		int x = this.offset;
		int y = this.screen.getHeight() - this.offset - this.diameter;
		this.setLocation(x, y);
		this.setSize(this.diameter, this.diameter);
		centerPoint = new Point(x + this.radius, y + this.radius);
	}

	/**
	 * �ж�ָ��λ���Ƿ��ڷ������
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	private boolean isIn(int x, int y)
	{
		return this.x() <= x && x <= this.x() + this.getWidth() && this.y() <= y && y <= this.y() + this.getHeight();
	}

	/**
	 * ���ݴ��ص�λ�ú����ĵ��λ�õõ���ǰ�ķ��򣬲���������������
	 */
	private void setDirection()
	{
		if (isTouchDown)
		{
			if (touchPoint.x > centerPoint.x)
			{
				this.mario.right();
			}
			else if (touchPoint.x < centerPoint.x)
			{
				this.mario.left();
			}
			else
			{
				this.mario.stop();
			}

			if (touchPoint.y > centerPoint.y)
			{
				this.mario.down();
			}
		}
		else
		{
			//this.mario.stop();
		}
	}
}
