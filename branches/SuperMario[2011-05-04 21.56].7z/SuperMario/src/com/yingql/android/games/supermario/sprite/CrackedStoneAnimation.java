package com.yingql.android.games.supermario.sprite;

import org.loon.framework.android.game.core.graphics.LImage;
import org.loon.framework.android.game.core.graphics.device.LGraphics;
import org.loon.framework.android.game.core.graphics.window.actor.Actor;
import org.loon.framework.android.game.core.graphics.window.actor.Speed;
import org.loon.framework.android.game.core.timer.LTimer;

import com.yingql.android.games.supermario.Map;

/**
 * ײ��ש��Ķ���
 * 
 * @author yingql
 * 
 */
public class CrackedStoneAnimation extends Actor
{
	private LTimer timer = new LTimer(0);
	private static LImage image = null;
	/**
	 * �������ŵĽ׶Σ���Ҫ���ݲ�ͬ�Ľ׶δ���ש����Ƭ����ת�Ƕ�
	 */
	private int step = 0;

	/**
	 * һ����Ҫ���Ŷ���֡
	 */
	private int maxStep = 16;

	/**
	 * ��Ϸ��ͼ
	 */
	private Map map;

	private boolean isStart = false;

	private CrackedStone[] crackedStones = new CrackedStone[4];

	public CrackedStoneAnimation(Map map)
	{
		this.map = map;
		timer.setDelay(50);
		if (image == null)
			image = new LImage("assets/bonus/cracked.png");

	}

	public void initLocation(int tileX, int tileY)
	{
		Speed gSpeed = new Speed(270, 8);
		double unitSpeed = 2;
		// ����
		Speed leftUp = new Speed(180, unitSpeed);
		leftUp.add(gSpeed);
		crackedStones[0] = new CrackedStone(image, this.map.tilesToPixels(tileX - 1, this.map.getTileWidth()), this.map.tilesToPixels(tileY - 1,
				this.map.getTileHeight()), 0, leftUp);
		// ����
		Speed rightUp = new Speed(0, unitSpeed);
		rightUp.add(gSpeed);
		crackedStones[1] = new CrackedStone(image, this.map.tilesToPixels(tileX + 1, this.map.getTileWidth()), this.map.tilesToPixels(tileY - 1,
				this.map.getTileHeight()), 0, rightUp);
		// ����
		Speed rightDown = new Speed(180, unitSpeed);
		rightDown.add(gSpeed);
		crackedStones[2] = new CrackedStone(image, this.map.tilesToPixels(tileX - 1, this.map.getTileWidth()), this.map.tilesToPixels(tileY + 1,
				this.map.getTileHeight()), 0, rightDown);
		// ����
		Speed leftDown = new Speed(0, unitSpeed);
		leftDown.add(gSpeed);
		crackedStones[3] = new CrackedStone(image, this.map.tilesToPixels(tileX + 1, this.map.getTileWidth()), this.map.tilesToPixels(tileY + 1,
				this.map.getTileHeight()), 0, leftDown);
	}

	public void start()
	{
		step = 0;
		isStart = true;
	}

	@Override
	public void action(long elapsedTime)
	{
		// ���ڴ����update����������������Ҫ�Լ������Ƿ񴥷�action�ļ���
		if (isStart && timer.action(elapsedTime))
		{
			// TODO ����4��ש����Ƭ�ĵ�λ��
			for (CrackedStone crackedStone : crackedStones)
			{
				if (crackedStone != null)
					crackedStone.action();
			}
			step++;
			if (step > maxStep)
				isStart = false;
		}
	}

	@Override
	public void draw(LGraphics g)
	{
		if (this.isStart)
		{
			// TODO �ֱ����4��ש����Ƭ
			for (CrackedStone crackedStone : crackedStones)
			{
				if (crackedStone != null)
					crackedStone.draw(g);
			}
		}
	}
}

/**
 * ש����Ƭ��
 * 
 * @author yingql
 * 
 */
class CrackedStone
{
	private LImage image;
	private int rotation;
	private double x, y;

	private Speed speed;

	public CrackedStone(LImage image, double x, double y, int rotation, Speed speed)
	{
		this.image = image;
		this.x = x;
		this.y = y;
		this.speed = speed;
		// System.out.println("Speed X:" + speed.getX() + ",Y:" + speed.getY());
		this.rotation = rotation;
	}

	public void action()
	{
		this.x += this.speed.getX();
		this.y += this.speed.getY();
		// ���������ٶ�
		this.speed.add(new Speed(90, 4));
	}

	public void draw(LGraphics g)
	{
		g.drawBitmap(image.getBitmap(), (int) x, (int) y);
	}
}
