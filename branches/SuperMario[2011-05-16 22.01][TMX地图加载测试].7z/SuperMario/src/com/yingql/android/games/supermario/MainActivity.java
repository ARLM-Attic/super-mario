package com.yingql.android.games.supermario;

import java.io.InputStream;

import org.loon.framework.android.game.LGameAndroid2DActivity;
import org.loon.framework.android.game.core.LSystem;

import com.yingql.android.game.engine.core.map.tmx.TMXLoader;
import com.yingql.android.game.engine.core.map.tmx.entity.TMXTiledMap;
import com.yingql.android.game.engine.util.StreamUtil;

public class MainActivity extends LGameAndroid2DActivity
{
	@Override
	public void onMain()
	{
		String fileName = "map/level 1-1.tmx";
		InputStream in = null;
		try
		{
			in = this.getResources().getAssets().open(fileName);
			TMXLoader loader = new TMXLoader();
			TMXTiledMap map = loader.load(in);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			StreamUtil.closeStream(in);
		}

		// ����֧�ֵ������Ļ���Ⱥ͸߶�
		LSystem.MAX_SCREEN_HEIGHT = 480;
		LSystem.MAX_SCREEN_WIDTH = 800;

		// ����������Ӧ
		setupGravity();
		// ����
		this.initialization(true);
		// ����ʾlogo
		this.setShowLogo(false);
		// ��ʾʵ��fps
		this.setShowFPS(true);
		// ��ʼ����ʹ��Test1
		this.setScreen(new MainScreen());
		// ��ʾ����
		this.showScreen();
	}
}