package com.yingql.android.games.supermario.tmx;

import java.util.Properties;

public class TMXProperty extends Properties
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
