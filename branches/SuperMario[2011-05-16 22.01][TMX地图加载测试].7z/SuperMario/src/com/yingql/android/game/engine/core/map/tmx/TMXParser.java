package com.yingql.android.game.engine.core.map.tmx;

import java.io.IOException;
import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.yingql.android.game.engine.core.map.tmx.entity.SAXTMXEntity;
import com.yingql.android.game.engine.core.map.tmx.entity.SAXTMXPropertyEntity;
import com.yingql.android.game.engine.core.map.tmx.entity.TMXConstants;
import com.yingql.android.game.engine.core.map.tmx.entity.TMXLayer;
import com.yingql.android.game.engine.core.map.tmx.entity.TMXObject;
import com.yingql.android.game.engine.core.map.tmx.entity.TMXObjectGroup;
import com.yingql.android.game.engine.core.map.tmx.entity.TMXProperty;
import com.yingql.android.game.engine.core.map.tmx.entity.TMXTileSet;
import com.yingql.android.game.engine.core.map.tmx.entity.TMXTiledMap;

public class TMXParser extends DefaultHandler
{
	private TMXTiledMap map;
	/**
	 * ��ǰ�ڽ����Ľڵ�
	 */
	private SAXTMXEntity currentEntity = null;
	private final StringBuilder stringBuilder = new StringBuilder();
	private String dataEncoding;
	private String dataCompression;

	public TMXTiledMap getTMXTiledMap()
	{
		return this.map;
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException
	{
		System.out.println("startElement:" + localName);
		if (localName.equals(TMXConstants.TAG_MAP))
		{
			this.map = new TMXTiledMap(attributes);
			this.currentEntity = this.map;
		}
		else if (localName.equals(TMXConstants.TAG_TILESET))
		{
			// TODO ���ڼ���������ﲻ���ǰ�tileset�����ڵ�����tsx�ļ������
			String tsxTileSetSource = attributes.getValue("", TMXConstants.TAG_TILESET_ATTRIBUTE_SOURCE);
			if (tsxTileSetSource != null)
				throw new SAXException("Unsupport tsx tileset in current version.");
			TMXTileSet tileSet = new TMXTileSet(attributes);
			tileSet.setParent(this.map);
			this.map.addTileSet(tileSet);
			this.currentEntity = tileSet;
		}
		else if (localName.equals(TMXConstants.TAG_IMAGE))
		{
		}
		else if (localName.equals(TMXConstants.TAG_TILE))
		{
		}
		else if (localName.equals(TMXConstants.TAG_PROPERTIES))
		{
		}
		else if (localName.equals(TMXConstants.TAG_PROPERTY))
		{
			// ���ݵ�ǰ�����Ĳ�ͬ�ڵ㣬���Զ����������ӵ��ڵ���
			if (this.currentEntity instanceof SAXTMXPropertyEntity)
			{
				SAXTMXPropertyEntity entity = (SAXTMXPropertyEntity) this.currentEntity;
				entity.addTMXProperty(new TMXProperty(attributes));
			}
		}
		else if (localName.equals(TMXConstants.TAG_LAYER))
		{
			TMXLayer layer = new TMXLayer(this.map, attributes);
			layer.setParent(this.map);
			this.map.addLayer(layer);
			this.currentEntity = layer;
		}
		else if (localName.equals(TMXConstants.TAG_DATA))
		{
			this.dataEncoding = attributes.getValue("", TMXConstants.TAG_DATA_ATTRIBUTE_ENCODING);
			this.dataCompression = attributes.getValue("", TMXConstants.TAG_DATA_ATTRIBUTE_COMPRESSION);
		}
		else if (localName.equals(TMXConstants.TAG_OBJECTGROUP))
		{
			TMXObjectGroup objectGroup = new TMXObjectGroup(attributes);
			objectGroup.setParent(this.map);
			this.map.addObjectGroup(objectGroup);
			this.currentEntity = objectGroup;
		}
		else if (localName.equals(TMXConstants.TAG_OBJECT))
		{
			final ArrayList<TMXObjectGroup> objectGroups = this.map.getObjectGroups();
			TMXObjectGroup objectGroup = objectGroups.get(objectGroups.size() - 1);
			TMXObject object = new TMXObject(attributes);
			object.setParent(objectGroup);
			objectGroup.addObject(object);
			this.currentEntity = object;
		}
		else
		{
			throw new SAXException("Unexpected start tag: '" + localName + "'.");
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException
	{
		stringBuilder.append(ch, start, length);
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException
	{		
		// ��������xml�ڵ�Ľ�����ǩ�������ýڵ�����
		if (localName.equals(TMXConstants.TAG_MAP))
		{
		}
		else if (localName.equals(TMXConstants.TAG_TILESET))
		{
		}
		else if (localName.equals(TMXConstants.TAG_IMAGE))
		{
		}
		else if (localName.equals(TMXConstants.TAG_TILE))
		{
		}
		else if (localName.equals(TMXConstants.TAG_PROPERTIES))
		{
		}
		else if (localName.equals(TMXConstants.TAG_PROPERTY))
		{
		}
		else if (localName.equals(TMXConstants.TAG_LAYER))
		{
		}
		else if (localName.equals(TMXConstants.TAG_DATA))
		{
			String data = stringBuilder.toString();
			System.out.println(data);
			// ��ѹlayer�е�data����
			final boolean binarySaved = this.dataCompression != null && this.dataEncoding != null;
			if (binarySaved)
			{
				final ArrayList<TMXLayer> tmxLayers = this.map.getLayers();
				try
				{
					TMXLayer layer = tmxLayers.get(tmxLayers.size() - 1);
					layer.initializeTMXTilesFromDataString(data.trim(), this.dataEncoding, this.dataCompression);
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
				this.dataCompression = null;
				this.dataEncoding = null;
			}
		}
		else if (localName.equals(TMXConstants.TAG_OBJECTGROUP))
		{
		}
		else if (localName.equals(TMXConstants.TAG_OBJECT))
		{
		}
		else
		{
			throw new SAXException("Unexpected end tag: '" + localName + "'.");
		}

		/* Reset the StringBuilder. */
		this.stringBuilder.setLength(0);

		System.out.println(this.currentEntity);
		// ��ǰ�ڵ���������ݻ���һ��ڵ�
		if (this.currentEntity != null)
		{
			this.currentEntity = this.currentEntity.getParent();
		}
		System.out.println("endElement:" + localName);
	}
}
