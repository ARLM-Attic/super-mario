package com.yingql.android.game.engine.core.map.tmx.entity;

import java.util.ArrayList;

import org.xml.sax.Attributes;

/**
 * ���Լ��ϵĻ���
 * 
 * @author yingql
 * 
 * @param <T>
 */
public class TMXProperties<T extends TMXProperty> extends ArrayList<T> implements SAXTMXEntity
{
	private SAXTMXEntity parent;

	private static final long serialVersionUID = 8912773556975105201L;

	/**
	 * �Ƿ����ָ��������
	 * 
	 * @param name
	 * @param value
	 * @return
	 */
	public boolean containsTMXProperty(final String name, final String value)
	{
		for (int i = this.size() - 1; i >= 0; i--)
		{
			final T tmxProperty = this.get(i);
			if (tmxProperty.getName().equals(name) && tmxProperty.getValue().equals(value))
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public void setParent(SAXTMXEntity parent)
	{
		this.parent = parent;
	}

	@Override
	public SAXTMXEntity getParent()
	{
		return this.parent;
	}

	@Override
	public void loadAttributes(Attributes attributes)
	{
	}
}
