package com.yingql.android.game.engine.core.map.tmx.exception;

/**
 * ��ͼ�����쳣��
 * 
 * @author yingql
 *
 */
public class TMXLoadException extends Exception
{
	private static final long serialVersionUID = 1007924721421015282L;

	public TMXLoadException() {
		super();
	}

	public TMXLoadException(final String detailMessage, final Throwable throwable) {
		super(detailMessage, throwable);
	}

	public TMXLoadException(final String detailMessage) {
		super(detailMessage);
	}

	public TMXLoadException(final Throwable throwable) {
		super(throwable);
	}
}
