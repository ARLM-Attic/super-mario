package com.yingql.android.game.engine.core.map.tmx.entity;

import org.xml.sax.Attributes;

/**
 * ����Property�ӽڵ��TMXʵ��
 * 
 * @author yingql
 * 
 */
public abstract class SAXTMXPropertyEntity extends DefaultSAXTMXEntity
{
	/**
	 * �ڵ��Properties�ӽڵ�
	 */
	private final TMXProperties<TMXProperty> properties = new TMXProperties<TMXProperty>();

	public SAXTMXPropertyEntity()
	{

	}

	public SAXTMXPropertyEntity(Attributes attributes)
	{
		super(attributes);
	}

	/**
	 * @return �ڵ��Properties�ӽڵ�
	 */
	public TMXProperties<TMXProperty> getProperties()
	{
		return properties;
	}

	/**
	 * ����property�ڵ�
	 * 
	 * @param property
	 */
	public void addTMXProperty(final TMXProperty property)
	{
		this.properties.add(property);
	}

	@Override
	public String toString()
	{
		String str = "";
		for (TMXProperty property : properties)
		{
			str += property.toString() + "\r\n";
		}
		return str;
	}
}
