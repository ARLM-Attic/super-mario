package com.yingql.android.game.engine.core.map.tmx.entity;

import java.util.ArrayList;

import org.xml.sax.Attributes;

import com.yingql.android.game.engine.util.SAXUtils;

public class TMXTiledMap extends SAXTMXPropertyEntity
{
	private String version;
	private Orientation orientation;
	private int tileColumns;
	private int tileRows;
	private int tileWidth;
	private int tileHeight;

	private final ArrayList<TMXTileSet> tileSets = new ArrayList<TMXTileSet>();

	private final ArrayList<TMXLayer> layers = new ArrayList<TMXLayer>();

	private final ArrayList<TMXObjectGroup> objectGroups = new ArrayList<TMXObjectGroup>();

	public TMXTiledMap(Attributes attributes)
	{
		super(attributes);
	}

	public String getVersion()
	{
		return version;
	}

	public Orientation getOrientation()
	{
		return orientation;
	}

	public int getTileColumns()
	{
		return tileColumns;
	}

	public int getTileRows()
	{
		return tileRows;
	}

	public int getTileWidth()
	{
		return tileWidth;
	}

	public int getTileHeight()
	{
		return tileHeight;
	}

	public int getWidthInPixel()
	{
		return this.tileColumns * this.tileWidth;
	}

	public int getHeightInPixel()
	{
		return this.tileRows * this.tileHeight;
	}

	/**
	 * �ڵ�ͼ������tileset
	 * 
	 * @param tmxTileSet
	 */
	public void addTileSet(TMXTileSet tmxTileSet)
	{
		tileSets.add(tmxTileSet);
	}

	public ArrayList<TMXTileSet> getTileSets()
	{
		return tileSets;
	}

	public void addLayer(final TMXLayer layer)
	{
		this.layers.add(layer);
	}

	public ArrayList<TMXLayer> getLayers()
	{
		return this.layers;
	}

	public void addObjectGroup(final TMXObjectGroup pTMXObjectGroup)
	{
		this.objectGroups.add(pTMXObjectGroup);
	}

	public ArrayList<TMXObjectGroup> getObjectGroups()
	{
		return this.objectGroups;
	}

	@Override
	public void loadAttributes(Attributes attributes)
	{
		this.version = SAXUtils.getAttribute(attributes, TAG_MAP_ATTRIBUTE_VERSION, TAG_MAP_ATTRIBUTE_VERSION_VALUE_DEFAULT);
		String orientationStr = attributes.getValue("", TAG_MAP_ATTRIBUTE_ORIENTATION);
		// ֻ֧�־��εĵ�ͼ
		if (!orientationStr.equals(TAG_MAP_ATTRIBUTE_ORIENTATION_VALUE_ORTHOGONAL))
		{
			throw new IllegalArgumentException(TAG_MAP_ATTRIBUTE_ORIENTATION + ": '" + orientationStr + "' is not supported.");
		}
		this.orientation = Orientation.Orthogonal;
		this.tileColumns = SAXUtils.getIntAttributeOrThrow(attributes, TAG_MAP_ATTRIBUTE_WIDTH);
		this.tileRows = SAXUtils.getIntAttributeOrThrow(attributes, TAG_MAP_ATTRIBUTE_HEIGHT);
		this.tileWidth = SAXUtils.getIntAttributeOrThrow(attributes, TAG_MAP_ATTRIBUTE_TILEWIDTH);
		this.tileHeight = SAXUtils.getIntAttributeOrThrow(attributes, TAG_MAP_ATTRIBUTE_TILEHEIGHT);
	}

	@Override
	public String toString()
	{
		return "<map version='" + this.version + "' orientation='" + this.orientation + "' width='" + this.tileColumns + "' height='" + this.tileRows
				+ " tileWidth='" + this.tileWidth + "' tileHeight='" + this.tileHeight + "'>" + super.toString() + "</map>";
	}

	/**
	 * 
	 * ��ͼ����
	 * 
	 * @author yingql
	 * 
	 */
	enum Orientation
	{
		/**
		 * ����
		 */
		Orthogonal,

		/**
		 * 45���ӽ�
		 */
		Isometric
	}
}
