package com.yingql.android.game.engine.core.map.tmx;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import com.yingql.android.game.engine.core.map.tmx.entity.TMXTiledMap;
import com.yingql.android.game.engine.core.map.tmx.exception.TMXLoadException;

/**
 * TMX������
 * 
 * @author yingql
 * 
 */
public class TMXLoader
{		
	/**
	 * ����TMX��ͼ
	 * 
	 * @param inputStream
	 *            tmx��ͼ��
	 * @return ���غõ�TMX��ͼ
	 * @throws TMXLoadException
	 */
	public TMXTiledMap load(final InputStream inputStream) throws TMXLoadException
	{
		try
		{
			// ʹ��SAX����xml��һ�㲽��
			final SAXParserFactory spf = SAXParserFactory.newInstance();
			final SAXParser sp = spf.newSAXParser();
			final XMLReader xr = sp.getXMLReader();
			final TMXParser tmxParser = new TMXParser();
			xr.setContentHandler(tmxParser);
			xr.parse(new InputSource(new BufferedInputStream(inputStream)));
			return tmxParser.getTMXTiledMap();
		}
		catch (final SAXException e)
		{
			throw new TMXLoadException(e);
		}
		catch (final IOException e)
		{
			throw new TMXLoadException(e);
		}
		catch (final Exception e)
		{
			throw new TMXLoadException(e);
		}
	}
}
