package com.yingql.android.game.engine.util;

public class StringUtil
{
	public static String padRight(final String str, int length, char padChar)
	{
		String result = str;
		int len = str.length();
		if (len < length)
		{
			result += padChar;
			len++;
		}
		return result;
	}
}
