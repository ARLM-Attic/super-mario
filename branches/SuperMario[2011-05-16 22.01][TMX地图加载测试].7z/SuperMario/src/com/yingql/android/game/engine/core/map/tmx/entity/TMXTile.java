package com.yingql.android.game.engine.core.map.tmx.entity;

import org.xml.sax.Attributes;

public class TMXTile extends SAXTMXPropertyEntity
{
	int gid;
	private int tileRow;
	private int tileColumn;
	private int tileWidth;
	private int tileHeight;

	public TMXTile(Attributes attributes)
	{
		super(attributes);
	}

	public TMXTile(final int gid, final int tileColumn, final int tileRow, final int tileWidth, final int tileHeight)
	{
		this.gid = gid;
		this.tileRow = tileRow;
		this.tileColumn = tileColumn;
		this.tileWidth = tileWidth;
		this.tileHeight = tileHeight;
	}

	public int getGid()
	{
		return gid;
	}

	public int getTileRow()
	{
		return tileRow;
	}

	public int getTileColumn()
	{
		return tileColumn;
	}

	public int getTileWidth()
	{
		return tileWidth;
	}

	public int getTileHeight()
	{
		return tileHeight;
	}

	@Override
	public void loadAttributes(Attributes attributes)
	{
	}
}
