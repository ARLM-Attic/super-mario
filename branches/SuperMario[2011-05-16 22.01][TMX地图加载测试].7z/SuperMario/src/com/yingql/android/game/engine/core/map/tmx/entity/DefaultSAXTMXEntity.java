package com.yingql.android.game.engine.core.map.tmx.entity;

import org.xml.sax.Attributes;

/**
 * Ĭ�ϵ�ʹ��SAX����TMX�ڵ�Ľӿ�ʵ��
 * 
 * @author yingql
 * 
 */
public abstract class DefaultSAXTMXEntity implements SAXTMXEntity
{
	private SAXTMXEntity parent;

	public DefaultSAXTMXEntity()
	{

	}

	public DefaultSAXTMXEntity(Attributes attributes)
	{
		loadAttributes(attributes);
	}

	@Override
	public void setParent(SAXTMXEntity parent)
	{
		this.parent = parent;
	}

	@Override
	public SAXTMXEntity getParent()
	{
		return this.parent;
	}

	@Override
	public abstract void loadAttributes(Attributes attributes);
}
