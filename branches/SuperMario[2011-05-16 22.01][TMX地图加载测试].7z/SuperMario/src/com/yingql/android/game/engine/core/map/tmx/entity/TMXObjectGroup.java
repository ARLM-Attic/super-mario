package com.yingql.android.game.engine.core.map.tmx.entity;

import java.util.ArrayList;

import org.xml.sax.Attributes;

import com.yingql.android.game.engine.util.SAXUtils;

public class TMXObjectGroup extends SAXTMXPropertyEntity
{
	private String name;
	private int width;
	private int height;
	private ArrayList<TMXObject> objects = new ArrayList<TMXObject>();

	public TMXObjectGroup(Attributes attributes)
	{
		super(attributes);
	}

	public String getName()
	{
		return name;
	}

	public int getWidth()
	{
		return width;
	}

	public int getHeight()
	{
		return height;
	}

	public ArrayList<TMXObject> getObjects()
	{
		return objects;
	}

	public void addObject(final TMXObject object)
	{
		this.objects.add(object);
	}

	@Override
	public void loadAttributes(Attributes attributes)
	{
		this.name = attributes.getValue("", TMXConstants.TAG_OBJECTGROUP_ATTRIBUTE_NAME);
		this.width = SAXUtils.getIntAttributeOrThrow(attributes, TMXConstants.TAG_OBJECTGROUP_ATTRIBUTE_WIDTH);
		this.height = SAXUtils.getIntAttributeOrThrow(attributes, TMXConstants.TAG_OBJECTGROUP_ATTRIBUTE_HEIGHT);
	}

	@Override
	public String toString()
	{
		String objectStr = "";
		for (TMXObject object : objects)
		{
			objectStr += object.toString() + "\r\n";
		}
		return "<objectGroup name='" + this.name + " width='" + this.width + "' height='" + this.height + "'>" + objectStr + super.toString()
				+ "</objectGroup>";
	}
}
