package com.yingql.android.game.engine.core.map.tmx.entity;

import org.xml.sax.Attributes;

/**
 * @author Nicolas Gramlich
 * @since 10:14:06 - 27.07.2010
 */
public class TMXProperty extends DefaultSAXTMXEntity
{
	private String name;
	private String value;

	public TMXProperty(final Attributes attributes)
	{
		super(attributes);
	}

	public String getName()
	{
		return this.name;
	}

	public String getValue()
	{
		return this.value;
	}

	@Override
	public String toString()
	{
		return "<property name='" + this.name + "' value='" + this.value + "'/>";
	}

	@Override
	public void loadAttributes(Attributes attributes)
	{
		this.name = attributes.getValue("", TAG_PROPERTY_ATTRIBUTE_NAME);
		this.value = attributes.getValue("", TAG_PROPERTY_ATTRIBUTE_VALUE);
	}
}
