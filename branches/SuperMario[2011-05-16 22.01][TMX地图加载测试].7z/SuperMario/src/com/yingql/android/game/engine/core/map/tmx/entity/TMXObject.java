package com.yingql.android.game.engine.core.map.tmx.entity;

import org.xml.sax.Attributes;

import com.yingql.android.game.engine.util.SAXUtils;

/**
 * object�ڵ�
 * 
 * @author yingql
 * 
 */
public class TMXObject extends SAXTMXPropertyEntity
{
	private String name;
	private String type;
	private int x;
	private int y;
	private int width;
	private int height;

	public TMXObject(Attributes attributes)
	{
		super(attributes);
	}

	public String getName()
	{
		return name;
	}

	public String getType()
	{
		return type;
	}

	public int getX()
	{
		return x;
	}

	public int getY()
	{
		return y;
	}

	public int getWidth()
	{
		return width;
	}

	public int getHeight()
	{
		return height;
	}

	@Override
	public void loadAttributes(Attributes attributes)
	{
		this.name = attributes.getValue("", TMXConstants.TAG_OBJECT_ATTRIBUTE_NAME);
		this.type = attributes.getValue("", TMXConstants.TAG_OBJECT_ATTRIBUTE_TYPE);
		this.x = SAXUtils.getIntAttributeOrThrow(attributes, TMXConstants.TAG_OBJECT_ATTRIBUTE_X);
		this.y = SAXUtils.getIntAttributeOrThrow(attributes, TMXConstants.TAG_OBJECT_ATTRIBUTE_Y);
		this.width = SAXUtils.getIntAttribute(attributes, TMXConstants.TAG_OBJECT_ATTRIBUTE_WIDTH, 0);
		this.height = SAXUtils.getIntAttribute(attributes, TMXConstants.TAG_OBJECT_ATTRIBUTE_HEIGHT, 0);
	}

	@Override
	public String toString()
	{
		return "<object name='" + this.name + "' type='" + this.type + "' x='" + this.x + "' y='" + this.y + " width='" + this.width + "' height='"
				+ this.height + "'>" + super.toString() + "</object>";
	}
}
