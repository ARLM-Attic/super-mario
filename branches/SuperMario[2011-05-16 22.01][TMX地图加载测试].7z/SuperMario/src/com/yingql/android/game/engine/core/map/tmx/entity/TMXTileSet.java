package com.yingql.android.game.engine.core.map.tmx.entity;

import org.xml.sax.Attributes;

import com.yingql.android.game.engine.util.SAXUtils;

public class TMXTileSet extends DefaultSAXTMXEntity
{
	private int firstGid;
	private int lastGid;
	private String name;
	private String source;
	private int tileWidth;
	private int tileHeight;
	private int spacing = 0;
	private int margin = 0;

	public TMXTileSet(Attributes attributes)
	{
		super(attributes);
	}

	public int getFirstGid()
	{
		return firstGid;
	}

	public int getLastGid()
	{
		return lastGid;
	}

	public String getName()
	{
		return name;
	}

	public String getSource()
	{
		return source;
	}

	public int getTileWidth()
	{
		return tileWidth;
	}

	public int getTileHeight()
	{
		return tileHeight;
	}

	public int getSpacing()
	{
		return spacing;
	}

	public int getMargin()
	{
		return margin;
	}

	@Override
	public void loadAttributes(Attributes attributes)
	{
		this.firstGid = SAXUtils.getIntAttribute(attributes, TAG_TILESET_ATTRIBUTE_FIRSTGID, 1);
		this.name = attributes.getValue("", TAG_TILESET_ATTRIBUTE_NAME);
		this.tileWidth = SAXUtils.getIntAttributeOrThrow(attributes, TAG_TILESET_ATTRIBUTE_TILEWIDTH);
		this.tileHeight = SAXUtils.getIntAttributeOrThrow(attributes, TAG_TILESET_ATTRIBUTE_TILEHEIGHT);
		this.spacing = SAXUtils.getIntAttribute(attributes, TAG_TILESET_ATTRIBUTE_SPACING, 0);
		this.margin = SAXUtils.getIntAttribute(attributes, TAG_TILESET_ATTRIBUTE_MARGIN, 0);
	}

	@Override
	public String toString()
	{
		return "<tileset firstgid='" + this.firstGid + "' name='" + this.name + "' tileWidth='" + this.tileWidth + "' tileHeight='" + this.tileHeight
				+ " spacing='" + this.spacing + "' margin='" + this.margin + "'/>";
	}
}
