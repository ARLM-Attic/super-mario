package com.yingql.android.game.engine.core.map.tmx.entity;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;

import org.xml.sax.Attributes;

import com.yingql.android.game.engine.util.SAXUtils;
import com.yingql.android.game.engine.util.StreamUtil;
import com.yingql.android.game.engine.util.StringUtil;

public class TMXLayer extends SAXTMXPropertyEntity
{
	private TMXTiledMap map;
	private String name;
	private int x = 0, y = 0;
	private int tileColumns;
	private int tileRows;
	private double opacity = 1;
	private boolean visible = true;
	private TMXTile[][] tiles;

	public TMXLayer(TMXTiledMap map, Attributes attributes)
	{
		super(attributes);
		this.map = map;
	}

	public String getName()
	{
		return name;
	}

	public int getX()
	{
		return x;
	}

	public int getY()
	{
		return y;
	}

	public int getTileColumns()
	{
		return tileColumns;
	}

	public int getTileRows()
	{
		return tileRows;
	}

	public double getOpacity()
	{
		return opacity;
	}

	public boolean isVisible()
	{
		return visible;
	}

	public int getWidthInPixel()
	{
		return this.tileColumns * this.map.getTileWidth();
	}

	public int getHeightInPixel()
	{
		return this.tileRows * this.map.getTileHeight();
	}

	@Override
	public void loadAttributes(Attributes attributes)
	{
		this.name = attributes.getValue("", TAG_LAYER_ATTRIBUTE_NAME);
		this.tileColumns = SAXUtils.getIntAttributeOrThrow(attributes, TAG_LAYER_ATTRIBUTE_WIDTH);
		this.tileRows = SAXUtils.getIntAttributeOrThrow(attributes, TAG_LAYER_ATTRIBUTE_HEIGHT);
		this.tiles = new TMXTile[this.tileRows][this.tileColumns];
		this.visible = SAXUtils.getIntAttribute(attributes, TAG_LAYER_ATTRIBUTE_VISIBLE, TAG_LAYER_ATTRIBUTE_VISIBLE_VALUE_DEFAULT) == 1;
		this.opacity = SAXUtils.getFloatAttribute(attributes, TAG_LAYER_ATTRIBUTE_OPACITY, TAG_LAYER_ATTRIBUTE_OPACITY_VALUE_DEFAULT);
	}

	public void initializeTMXTilesFromDataString(final String dataString, final String dataEncoding, final String dataCompression)
			throws IOException, IllegalArgumentException
	{
		DataInputStream inputStream = null;
		try
		{
			System.out.println("start");
			InputStream in = new ByteArrayInputStream(dataString.trim().getBytes("UTF-8"));
			System.out.println("decodeBase64");
			/* Wrap decoding Streams if neccessary. */
			if (dataEncoding != null && dataEncoding.equals(TAG_DATA_ATTRIBUTE_ENCODING_VALUE_BASE64))
			{
				char[] enc = dataString.trim().toCharArray();
				byte[] dec = StreamUtil.decodeBase64(enc);
				in = new ByteArrayInputStream(dec);
			}
			System.out.println("GZIPInputStream");
			if (dataCompression != null)
			{
				if (dataCompression.equals(TAG_DATA_ATTRIBUTE_COMPRESSION_VALUE_GZIP))
				{
					in = new GZIPInputStream(in);
				}
				else
				{
					throw new IllegalArgumentException("Supplied compression '" + dataCompression + "' is not supported yet.");
				}
			}
			System.out.println("readGID");
			inputStream = new DataInputStream(in);

			int index = 0;

			int size = this.tileColumns * this.tileRows;
			while (index < size)
			{
				final int gid = this.readGID(inputStream);
				this.addTileByGID(gid, index);
				index++;
			}
			System.out.println("end");
		}
		finally
		{
			StreamUtil.closeStream(inputStream);
		}
	}

	private void addTileByGID(final int gid, final int index)
	{
		final int column = index % this.tileColumns;
		final int row = index / this.tileColumns;

		final TMXTile tmxTile = new TMXTile(gid, column, row, this.map.getTileWidth(), this.map.getTileHeight());
		this.tiles[row][column] = tmxTile;
	}

	/**
	 * ��ȡGID ����little-endian��˳�򱣴�
	 * 
	 * @param inputStream
	 * @return
	 * @throws IOException
	 */
	private int readGID(final DataInputStream inputStream) throws IOException
	{
		final int lowestByte = inputStream.read();
		final int secondLowestByte = inputStream.read();
		final int secondHighestByte = inputStream.read();
		final int highestByte = inputStream.read();

		if (lowestByte < 0 || secondLowestByte < 0 || secondHighestByte < 0 || highestByte < 0)
		{
			throw new IllegalArgumentException("Couldn't read global Tile ID.");
		}

		return lowestByte | secondLowestByte << 8 | secondHighestByte << 16 | highestByte << 24;
	}

	@Override
	public String toString()
	{
		String tileStr = "";
		for (TMXTile[] tileRow : this.tiles)
		{
			for (TMXTile tile : tileRow)
			{
				if (tile != null)
				{
					String temp = tile.getGid() + "";
					tileStr += StringUtil.padRight(temp, 4, ' ');
				}
			}
			tileStr += "\r\n";
		}
		return "<layer name='" + this.name + "' width='" + this.tileColumns + "' height='" + this.tileRows + "' visible='" + this.visible
				+ "' opacity='" + this.opacity + "'>" + tileStr + super.toString() + "</layer>";
	}
}
