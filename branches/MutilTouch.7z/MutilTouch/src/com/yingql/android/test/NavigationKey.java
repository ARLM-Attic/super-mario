package com.yingql.android.test;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;

public class NavigationKey
{
	private int x, y, radius;
	private Paint paint;
	private boolean isTouchDown = false;
	private int pid = -1;
	private int tx, ty;

	public NavigationKey(int x, int y, int radius)
	{
		this.x = x;
		this.y = y;
		this.tx = x;
		this.ty = y;
		this.radius = radius;
		this.paint = new Paint();
		this.paint.setColor(Color.BLUE);
		System.out.println("x��" + x + ",y:" + y + ",r:" + radius);
	}

	public void update(MotionEvent event)
	{
		int action = event.getAction();
		int actionCode = action & MotionEvent.ACTION_MASK;
		System.out.println(actionCode);
		int id, index;
		switch (actionCode)
		{
			case MotionEvent.ACTION_DOWN:
				// ���㰴�£���ʱ��ֻҪ�ڷ�Χ�ھ�˵���ɹ�
				if (isIn((int) event.getX(), (int) event.getY()))
				{
					System.out.println("ACTION_DOWN");
					this.isTouchDown = true;
					this.tx = (int) event.getX();
					this.ty = (int) event.getY();
					this.pid = event.getPointerId(0);
				}
				break;
			case MotionEvent.ACTION_MOVE:
				if (isTouchDown)
				{
					index = findIndexByPid(event, this.pid);
					if (index != -1)
					{
						this.tx = (int) event.getX(index);
						this.ty = (int) event.getY(index);
					}
				}
				break;
			case MotionEvent.ACTION_UP:
				// ��������
				if (isTouchDown)
				{
					id = event.getPointerId(0);
					if (id == this.pid)
					{
						isTouchDown = false;
						this.pid = -1;
					}
				}
				break;
			case MotionEvent.ACTION_POINTER_DOWN:
				id = action >> MotionEvent.ACTION_POINTER_ID_SHIFT;
				index = findIndexByPid(event, id);
				if (index != -1 && isIn((int) event.getX(index), (int) event.getY(index)))
				{
					this.isTouchDown = true;
					this.tx = (int) event.getX(index);
					this.ty = (int) event.getY(index);
					this.pid = id;
				}
				//Move
				else					
				{
					index = findIndexByPid(event, this.pid);
					if (index != -1)
					{
						this.tx = (int) event.getX(index);
						this.ty = (int) event.getY(index);
					}
				}
				break;
			case MotionEvent.ACTION_POINTER_UP:
				id = action >> MotionEvent.ACTION_POINTER_ID_SHIFT;
				if (id == this.pid)
				{
					isTouchDown = false;
					this.pid = -1;
				}
				//Move
				else
				{
					index = findIndexByPid(event, this.pid);
					if (index != -1)
					{
						this.tx = (int) event.getX(index);
						this.ty = (int) event.getY(index);
					}
				}
				break;
		}
	}	

	private int findIndexByPid(MotionEvent event, int id)
	{
		int index = -1;
		for (int i = 0; i < event.getPointerCount(); i++)
		{
			if (event.getPointerId(i) == id)
			{
				index = i;
				break;
			}
		}
		return index;
	}

	public void draw(Canvas cvs)
	{
		if (isTouchDown)
			cvs.drawCircle(tx, ty, radius, paint);
		else
			cvs.drawCircle(x, y, radius, paint);
	}

	private boolean isIn(int x, int y)
	{
		return this.x - this.radius <= x && x <= this.x + this.radius && this.y - this.radius <= y && y <= this.y + this.radius;
	}
}
